import re

#     212 - 456 - 7890
#     212 . 456 . 7890
#     212   456   7890
# +1  212 . 456 . 7890
#  +  212 - 456 - 7890
# 1-  212 - 456 - 7890    

phone_number = "[\s|+|+1|1-][212][-|.|\s|]\d{3}[-|.|\s]\d{4}$"

user_number = input("Enter your Phone_No : ")

if re.search(phone_number, user_number):
    print("You have entered a correct phone_no")
else:
    print("Please enter the correct phone_no.")
    