from bs4 import BeautifulSoup
import requests

url = input("Enter the input url: ")

result = requests.get(url)
doc = BeautifulSoup(result.text, "html.parser")
#format = doc.prettify()
#print(format)

link_list = doc.find_all('a')

for link in link_list:
    href = link['href']
    if href:
        if r"fulioTech" in href:
            print("Facebook URL :",f"{href}")
        if r"ful-io" in href:
            print("Linkdin URL :",f"{href}")
        if r"ful.io" in href:
            print("Mail ID: ",f"{href}")
        if r"+1" in href:
            print("Contact No: ",f"{href}")


